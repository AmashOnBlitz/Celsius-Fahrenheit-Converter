#include <iostream>
#include <string>
std::string coutGreenText(std::string texttaken);
std::string coutRedText(std::string texttaken);
std::string coutBoldText(std::string texttaken);
std::string coutUnderlineText(std::string texttaken);
std::string coutInvertedText(std::string texttaken);
std::string coutBoldGreenText(std::string texttaken);
std::string coutBoldRedText(std::string texttaken);
std::string coutBoldUnderlineText(std::string texttaken);
std::string coutBoldInvertedText(std::string texttaken);
std::string coutYellowText(std::string texttaken);
std::string coutBlueText(std::string texttaken);
std::string coutBoldYellowText(std::string texttaken);
std::string coutBoldItalicRedText(std::string texttaken);