#include <iostream>
#include "textdecorationfunctions.h"
#include "functionsofcalculation.h"

int CheckOperation(char reqopr);
int startOperation();
int askMore();

int main()
{
    std::cout << coutBoldText(coutGreenText( R"(
 _____                                   _                        
|_   _|__ _ __ ___  _ __   ___ _ __ __ _| |_ _   _ _ __ ___       
  | |/ _ \ '_ ` _ \| '_ \ / _ \ '__/ _` | __| | | | '__/ _ \      
  | |  __/ | | | | | |_) |  __/ | | (_| | |_| |_| | | |  __/      
 _|_|\___|_| |_| |_| .__/_\___|_|  \__,_|\__|\__,_|_|  \___|      
| | | |_ __ (_) |_ |_/ ___|___  _ ____   _____ _ __| |_ ___  _ __ 
| | | | '_ \| | __| | |   / _ \| '_ \ \ / / _ \ '__| __/ _ \| '__|
| |_| | | | | | |_  | |__| (_) | | | \ V /  __/ |  | || (_) | |   
 \___/|_| |_|_|\__|  \____\___/|_| |_|\_/ \___|_|   \__\___/|_|   


 )")) << std::endl;

    std::cout << coutBoldText(coutBlueText(R"(
                  Made by Amash On Blitz
)"));
    std::cout << coutBoldGreenText(R"(
                          Welcome
)") << std::endl;
    startOperation();
	return 0;

}






int CheckOperation(char reqopr) {
    if (reqopr == 'a') {
        double celsius;
		std::cout << coutBoldItalicRedText("Enter the temperature in Celsius : ");
		std::cin >> celsius;
        celsiustoFarenheit(celsius);
        askMore();
    }
    else if (reqopr == 'b') {
        double farenheit;
		std::cout << coutBoldItalicRedText("Enter the temperature in Fahrenheit : ");
		std::cin >> farenheit;
		farenheitToCelsius(farenheit);
        askMore();
    }
	else if (reqopr == 'c') {
		std::cout << coutBoldText(coutBlueText("Thank you for using the converter")) << std::endl;
		return 0;
	}
	else {
		std::cout << coutBoldRedText("Invalid Operation") << std::endl;
        std::cout << coutBoldItalicRedText("Enter the operation you want to do : ") << std::endl;
        std::cout << coutBoldItalicRedText(" (a) Celsius to Fahrenheit ")<<std::endl;
        std::cout << coutBoldItalicRedText(" (b) Fahrenheit to Celsius ") << std::endl;
        std::cout << coutBoldItalicRedText(" (c) Exit ") << std::endl;
        std::cin >> reqopr;
		CheckOperation(reqopr);
        return 0;
}
return 0;
}





int startOperation() {
    char opreration;
    std::cout << std::endl;
    std::cout << std::endl;
    std::cout << coutBoldItalicRedText("Enter the operation you want to do : ") << std::endl;
    std::cout << coutBoldItalicRedText(" (a) Celsius to Fahrenheit ") << std::endl;
    std::cout << coutBoldItalicRedText(" (b) Fahrenheit to Celsius ") << std::endl;
    std::cout << coutBoldItalicRedText(" (c) Exit ") << std::endl;
    std::cout << " ";
    std::cin >> opreration;
    CheckOperation(opreration);
    return 0;
}

int askMore() {
    char ask;
	std::cout << coutBoldItalicRedText("Do you want to continue ? (y/n) : ");
	std::cin >> ask;
	if (ask == 'y') {
		startOperation();
	}
	else if (ask == 'n') {
		std::cout << coutBoldText(coutBlueText("Thank you for using the converter")) << std::endl;
		return 0;
	}
	else {
		std::cout << coutBoldRedText("Invalid Operation") << std::endl;
		askMore();
	}
    return 0;

}
