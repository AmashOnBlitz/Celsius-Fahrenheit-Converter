int celsiustoFarenheit(double givencelsius);
int farenheitToCelsius(double givenfarenheit);