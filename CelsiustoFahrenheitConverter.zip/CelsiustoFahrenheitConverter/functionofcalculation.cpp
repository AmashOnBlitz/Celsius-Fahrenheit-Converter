#include <iostream>
#include "functionsofcalculation.h"
#include "textdecorationfunctions.h"

int  celsiustoFarenheit(double givencelsius) {
	double farenhite = (givencelsius * 9.0 / 5.0) + 32;
	std::cout << coutBoldText(coutYellowText("The temperature in Farenheit is : ")) << farenhite << std::endl;
	return farenhite;
}

int farenheitToCelsius(double givenfarenheit) {
	double celsius = (givenfarenheit - 32) * 5.0 / 9.0;
	std::cout << coutBoldText(coutYellowText("The temperature in Celsius is : ")) << celsius << std::endl;
	return celsius;
}